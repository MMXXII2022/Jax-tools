# JaxTools
***
A module in which you define your own objects using builtin tools for resetting
adding help statements, text, and names or references.

***